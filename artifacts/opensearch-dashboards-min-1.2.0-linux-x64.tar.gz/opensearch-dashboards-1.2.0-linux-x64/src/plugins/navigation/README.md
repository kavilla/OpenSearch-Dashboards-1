# navigation

The navigation plugins exports the `TopNavMenu` component.
It also provides a stateful version of it on the `start` contract.

