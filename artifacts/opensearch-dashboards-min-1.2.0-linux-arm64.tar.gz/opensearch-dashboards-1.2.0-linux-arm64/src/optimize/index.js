"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "optimizeMixin", {
  enumerable: true,
  get: function () {
    return _optimize_mixin.optimizeMixin;
  }
});

var _optimize_mixin = require("./optimize_mixin");