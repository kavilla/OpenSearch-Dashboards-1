# opensearch-dashboards-overview

> An overview page highlighting OpenSearch Dashboards apps

---

## Development

See the [OpenSearch Dashboards contributing guide](https://github.com/opensearch-project/OpenSearch-Dashboards/blob/master/CONTRIBUTING.md) for instructions setting up your development environment.
