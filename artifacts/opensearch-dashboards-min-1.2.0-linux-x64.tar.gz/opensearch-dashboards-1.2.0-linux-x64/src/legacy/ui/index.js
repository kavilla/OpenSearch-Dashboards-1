"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "uiMixin", {
  enumerable: true,
  get: function () {
    return _ui_mixin.uiMixin;
  }
});

var _ui_mixin = require("./ui_mixin");