"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "opensearchKuery", {
  enumerable: true,
  get: function () {
    return _server.opensearchKuery;
  }
});

var _server = require("../../../plugins/data/server");