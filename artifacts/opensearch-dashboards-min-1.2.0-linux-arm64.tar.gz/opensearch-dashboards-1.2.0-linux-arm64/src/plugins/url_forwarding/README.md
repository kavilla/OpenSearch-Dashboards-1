# url-forwarding

This plugins contains helpers to redirect legacy URLs. It can be used to forward old URLs to their new counterparts.
