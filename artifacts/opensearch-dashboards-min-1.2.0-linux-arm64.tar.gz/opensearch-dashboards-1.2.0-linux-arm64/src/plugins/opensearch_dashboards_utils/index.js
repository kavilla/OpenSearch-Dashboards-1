"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "createStateContainer", {
  enumerable: true,
  get: function () {
    return _common.createStateContainer;
  }
});
Object.defineProperty(exports, "StateContainer", {
  enumerable: true,
  get: function () {
    return _common.StateContainer;
  }
});
Object.defineProperty(exports, "of", {
  enumerable: true,
  get: function () {
    return _common.of;
  }
});

var _common = require("./common");