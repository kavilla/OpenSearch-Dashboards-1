# OpenSearch-Dashboards-legacy

This plugin contains several helpers and services to integrate pieces of the legacy OpenSearch Dashboards app with the new OpenSearch Dashboards platform.

This plugin will be removed once all parts of legacy OpenSearch Dashboards are removed from other plugins.

All of this plugin should be considered deprecated. New code should never integrate with the services provided from this plugin.