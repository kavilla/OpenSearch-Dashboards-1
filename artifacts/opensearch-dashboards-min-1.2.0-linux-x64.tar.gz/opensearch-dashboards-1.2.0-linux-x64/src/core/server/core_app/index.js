"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "CoreApp", {
  enumerable: true,
  get: function () {
    return _core_app.CoreApp;
  }
});

var _core_app = require("./core_app");