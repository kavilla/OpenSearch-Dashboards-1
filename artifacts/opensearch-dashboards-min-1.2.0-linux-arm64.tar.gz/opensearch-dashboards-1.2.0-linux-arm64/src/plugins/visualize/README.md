Contains the visualize application which includes the listing page and the app frame,
which will load the visualization's editor.