Contains most of the visualization infrastructure, e.g. the visualization type registry or the 
visualization embeddable.