"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "startRepl", {
  enumerable: true,
  get: function () {
    return _repl.startRepl;
  }
});

var _repl = require("../../../cli/repl");