# opensearch-dashboards-utils

Utilities for building OpenSearch Dashboards plugins.

- [State containers](./docs/state_containers).
- [State syncing utilities](./docs/state_sync).
